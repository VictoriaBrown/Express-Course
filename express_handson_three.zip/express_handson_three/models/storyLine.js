module.exports.storyLine = [
    {
        storyPart: "beginning",
        name: "Rupert",
        animal: "fox",
        age: 8
    },
    {   
        storyPart: "middle",
        place: "France",
        travelVehicle: "train",
        yearsToStay: 2
    },
    {
        storyPart: "end",
        foxWife: "Amelie",
        housing: "a house next to the Eiffel Tower"
    }
]